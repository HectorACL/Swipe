
//  ViewController.swift
//  Swipe
//
//  Created by Mac7 on 11/5/16.
//  Copyright © 2016 Mac7. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    let fotos = ["1.jpg", "2.jpg", "3.jpg", "4.jpg", "5.jpg"]
    var idx = 0
                 
    @IBOutlet weak var Album: UIImageView!

    @IBAction func DelizDer(sender: UISwipeGestureRecognizer){
        switch sender.direction{
        case UISwipeGestureRecognizerDirection.Right:
            idx = (idx + 1) % fotos.count
        case UISwipeGestureRecognizerDirection.Left:
            idx = (idx - 1)
            
            if idx < 0 {
                idx = fotos.count - 1
            }
            default: break
        }
        Album.image = UIImage(named: fotos[idx])
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

